// Banco de dados fake para simular Firebase no Expo Snack

export const dbFake = {
  tokenAtual: "ABC123",
  presencas: {},

  gerarToken() {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let t = "";
    for (let i = 0; i < 6; i++) t += chars[Math.floor(Math.random() * chars.length)];
    this.tokenAtual = t;
    return t;
  },

  registrarPresenca(nome) {
    this.presencas[nome] = new Date();
  }
};
