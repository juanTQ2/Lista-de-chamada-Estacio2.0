  // AppNavigator.js
  import { createNativeStackNavigator } from "@react-navigation/native-stack";

import AlunoScreen from "../screens/AlunoScreen";
import LoginScreen from "../screens/LoginScreen";
import ProfessorScreen from "../screens/ProfessorScreen";

  const Stack = createNativeStackNavigator();

  export default function AppNavigator() {
    return (
      <Stack.Navigator initialRouteName="Login">
        
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ title: "Lista de Presença" }}
        />

        <Stack.Screen
          name="Professor"
          component={ProfessorScreen}
          options={{ title: "Token da Aula" }}
        />

        <Stack.Screen
          name="Aluno"
          component={AlunoScreen}
          options={{ title: "Aluno" }}
        />

      </Stack.Navigator>
    );
  }
