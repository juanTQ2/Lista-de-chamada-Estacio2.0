import { useEffect, useState } from "react";
import { Text, View, FlatList, StyleSheet } from "react-native";
import { dbFake } from "../utils/databaseFake";

export default function HomeScreen() {
  const [token, setToken] = useState(dbFake.tokenAtual);
  const [presencas, setPresencas] = useState({});

  useEffect(() => {
    const interval = setInterval(() => {
      setToken(dbFake.tokenAtual);
      setPresencas({ ...dbFake.presencas });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Chamada ao Vivo</Text>
      <Text style={styles.token}>{token}</Text>

      <FlatList
        data={Object.keys(presencas)}
        renderItem={({ item }) => (
          <Text style={styles.item}>
            {item} — {presencas[item].toLocaleTimeString()}
          </Text>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  titulo: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
  token: { fontSize: 40, fontWeight: "bold", marginBottom: 20 },
  item: { fontSize: 18, paddingVertical: 5 }
});

