import { useEffect, useState } from "react";
import { Text, View, FlatList, StyleSheet } from "react-native";
import { dbFake } from "../utils/databaseFake";

export default function ProfessorScreen() {
  const [token, setToken] = useState(dbFake.tokenAtual);
  const [presencas, setPresencas] = useState({});

  useEffect(() => {
    const intervalToken = setInterval(() => {
      setToken(dbFake.gerarToken());
    }, 240000);

    const intervalPresencas = setInterval(() => {
      setPresencas({ ...dbFake.presencas });
    }, 1000);

    return () => {
      clearInterval(intervalToken);
      clearInterval(intervalPresencas);
    };
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Token da Aula</Text>

      <View style={styles.tokenBox}>
        <Text style={styles.token}>{token}</Text>
      </View>

      <Text style={styles.subtitle}>Presenças</Text>

      <FlatList
        data={Object.keys(presencas)}
        renderItem={({ item }) => (
          <Text style={styles.item}>
            {item} - {presencas[item].toLocaleTimeString()}
          </Text>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 26, fontWeight: "bold", marginBottom: 20 },
  tokenBox: {
    padding: 20, backgroundColor: "#fff",
    borderRadius: 10, alignItems: "center", marginBottom: 20,
  },
  token: { fontSize: 40, fontWeight: "bold", color: "#2b8" },
  subtitle: { fontSize: 22, marginBottom: 10 },
  item: { padding: 10, backgroundColor: "#eee", borderRadius: 8, marginBottom: 5 }
});

