import { useState } from "react";
import { Alert, Button, StyleSheet, Text, TextInput, View } from "react-native";
import { dbFake } from  "../utils/databaseFake";

export default function AlunoScreen() {
  const [nome, setNome] = useState("");
  const [token, setToken] = useState("");

  function marcar() {
    if (!nome || !token) return Alert.alert("Erro", "Preencha tudo.");

    if (token !== dbFake.tokenAtual)
      return Alert.alert("Token errado!");

    dbFake.registrarPresenca(nome);
    Alert.alert("Presença registrada!");
    setNome("");
    setToken("");
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Marcar Presença</Text>

      <TextInput
        placeholder="Seu nome"
        style={styles.input}
        value={nome}
        onChangeText={setNome}
      />

      <TextInput
        placeholder="Token"
        style={styles.input}
        value={token}
        onChangeText={setToken}
      />

      <Button title="Enviar" onPress={marcar} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: "center" },
  title: { fontSize: 26, fontWeight: "bold", marginBottom: 20 },
  input: {
    borderWidth: 1, borderColor: "#aaa",
    padding: 10, marginBottom: 10, borderRadius: 8
  }
});

