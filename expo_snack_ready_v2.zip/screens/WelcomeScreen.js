import { Button, StyleSheet, View } from "react-native";

export default function WelcomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Button title="Entrar (Professora)" onPress={() => navigation.navigate("Login")} />
      <View style={{ height: 20 }} />
      <Button title="Acesso Aluno" onPress={() => navigation.navigate("Aluno")} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
});
