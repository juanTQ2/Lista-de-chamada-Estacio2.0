import { useState } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";
import { dbFake } from "../utils/databaseFake";

export default function MarcarPresenca() {
  const [nome, setNome] = useState("");
  const [token, setToken] = useState("");

  function marcar() {
    if (!nome || !token) {
      Alert.alert("Erro", "Preencha tudo.");
      return;
    }

    if (token !== dbFake.tokenAtual) {
      Alert.alert("Erro", "Token inválido.");
      return;
    }

    dbFake.registrarPresenca(nome);

    Alert.alert("Sucesso!", "Presença registrada.");
    setNome("");
    setToken("");
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Marcar Presença</Text>

      <TextInput
        placeholder="Seu nome"
        style={styles.input}
        value={nome}
        onChangeText={setNome}
      />

      <TextInput
        placeholder="Token"
        style={styles.input}
        value={token}
        onChangeText={setToken}
      />

      <Button title="Registrar" onPress={marcar} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: "center" },
  titulo: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
  input: {
    borderWidth: 1, borderColor: "#ccc",
    padding: 10, borderRadius: 8,
    marginBottom: 10,
  },
});
